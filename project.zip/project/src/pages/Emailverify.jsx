import React, { useContext, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppContent } from '../context/AppContext';
import axios from 'axios';

axios.defaults.withCredentials = true;

const Emailverify = () => {
    const navigate = useNavigate();
    const { backendUrl, setIsLoggedin, getUserData } = useContext(AppContent);

    const [code, setCode] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const hasSentOtp = useRef(false);

    useEffect(() => {
        if (hasSentOtp.current) return;
        hasSentOtp.current = true;

        const sendOtpEmail = async () => {
            try {
                await axios.post(`${backendUrl}/api/auth/send-verify-otp`);
            } catch (err) {
                console.error("Failed to send OTP automatically:", err.message);
            }
        };

        sendOtpEmail();
    }, [backendUrl]);

    const handleCodeChange = (e) => {
        const value = e.target.value.replace(/\D/g, '');
        setCode(value);
        if (value.length === 6) setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');

        if (!code) { setError("OTP code is required"); return; }
        if (code.length !== 6) { setError("OTP must be exactly 6 digits"); return; }

        setLoading(true);
        try {
            const { data } = await axios.post(
                `${backendUrl}/api/auth/verify-account`,
                { optCode: code },
                { withCredentials: true }
            );

            if (data.success) {
                setIsLoggedin(true);
                await getUserData();
                navigate("/login");
            } else {
                setError(data.message || "Verification failed");
            }
        } catch (err) {
            setError(err.response?.data?.message || err.message || "Server connectivity issue");
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <div className="nav">
                <div className="logo"><h1>No Parking Pickup</h1></div>
                <div className="theme">
                    <label htmlFor="theme" style={{ display: 'inline', marginRight: '10px' }}>Theme</label>
                    <select name="theme" id="theme" style={{ background: '#111122', color: 'white', padding: '5px', borderRadius: '5px' }}>
                        <optgroup label='dark'>
                            <option value="Midnight">Midnight</option>
                            <option value="Obsedian">Obsedian</option>
                        </optgroup>
                        <optgroup label='light'>
                            <option value="Daylight">Daylight</option>
                            <option value="Parchment">Parchment</option>
                            <option value="Artic">Artic</option>
                        </optgroup>
                    </select>
                </div>
            </div>

            <div className="samosa">
                <div className="jalebi">
                    <h1>Security</h1>
                    <h2>Verify Email</h2>
                    <p>We sent a verification code to your email. Please enter it below to activate your account.</p>

                    <form onSubmit={handleSubmit}>
                        <input
                            type="text"
                            placeholder="Enter 6-Digit OTP"
                            maxLength="6"
                            value={code}
                            onChange={handleCodeChange}
                            disabled={loading}
                            style={{ textAlign: 'center', letterSpacing: '4px', fontSize: '18px' }}
                        />
                        {error && <p className='error' style={{ marginTop: '5px' }}>{error}</p>}
                        <button type="submit" disabled={loading}>
                            {loading ? 'Verifying...' : 'Verify Account'}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default Emailverify;