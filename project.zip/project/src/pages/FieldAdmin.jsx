import React, { useContext, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'
import { AppContent } from '../context/AppContext'
import { VIOLATION_STATUS_LABEL } from '../utils/constant'
import { getViolationStatusClass } from '../utils/helpers'

const PAGE_SIZE = 7

const FieldAdmin = () => {
    const { backendUrl, userData } = useContext(AppContent)
    const navigate = useNavigate()

    const api = axios.create({ baseURL: backendUrl, withCredentials: true })

    const [form, setForm] = useState({ plateNumber: '', location: '', fineAmount: 500 })
    const [ocrLoading, setOcrLoading] = useState(false)
    const [image, setImage] = useState(null)
    const [preview, setPreview] = useState(null)
    const [ownerInfo, setOwnerInfo] = useState(null)
    const [violations, setViolations] = useState([])
    const [message, setMessage] = useState({ type: '', text: '' })
    const [page, setPage] = useState(1)
    const [loading, setLoading] = useState({ lookup: false, submit: false, violations: true })

    const showMessage = (type, text) => setMessage({ type, text })
    const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value })

    const resetForm = () => {
        setForm({ plateNumber: '', location: '', fineAmount: 500 })
        setImage(null)
        setPreview(null)
        setOwnerInfo(null)
    }

    const fetchViolations = async () => {
        try {
            const { data } = await api.get('/api/field-admin/violations')
            if (data.success) setViolations(data.violations)
        } catch (err) {
            console.log(err.message)
        } finally {
            setLoading(prev => ({ ...prev, violations: false }))
        }
    }

    useEffect(() => { fetchViolations() }, [])

    const lookupVehicle = async () => {
        if (!form.plateNumber.trim()) return
        setLoading(prev => ({ ...prev, lookup: true }))
        setOwnerInfo(null)
        try {
            const plate = form.plateNumber.trim().toUpperCase()
            const { data } = await api.get(`/api/vehicle/${plate}`)
            if (data.success) {
                setOwnerInfo(data.vehicle)
                showMessage('', '')
            } else {
                showMessage('error', `Vehicle not found: ${plate}`)
            }
        } catch (err) {
            showMessage('error', err.message)
        } finally {
            setLoading(prev => ({ ...prev, lookup: false }))
        }
    }

    const handleImageChange = async (e) => {
        const file = e.target.files[0]
        if (!file) return
        setImage(file)
        setPreview(URL.createObjectURL(file))
        setOcrLoading(true)
        setMessage({ type: '', text: '' })
        try {
            const formData = new FormData()
            formData.append('image', file)
            const { data } = await api.post('/api/ocr/read-plate', formData)
            if (data.success) {
                setForm(prev => ({ ...prev, plateNumber: data.plate }))
                showMessage('success', `Plate detected: ${data.plate} ${!data.patternMatched ? '(verify manually)' : ''}`)
                const { data: vehicleData } = await api.get(`/api/vehicle/${data.plate}`)
                if (vehicleData.success) {
                    setOwnerInfo(vehicleData.vehicle)
                } else {
                    setOwnerInfo(null)
                    showMessage('error', `Plate detected as ${data.plate} but not found in database. Verify manually.`)
                }
            } else {
                showMessage('error', `OCR failed: ${data.message}. Enter plate manually.`)
            }
        } catch (err) {
            showMessage('error', 'OCR failed. Enter plate number manually.')
        } finally {
            setOcrLoading(false)
        }
    }

    const validateForm = () => {
        if (!form.plateNumber.trim()) return 'Plate number is required'
        if (!ownerInfo) return 'Vehicle not found'
        if (!form.location.trim()) return 'Location is required'
        if (!image) return 'Image is required'
        return null
    }

    const handleSubmit = async () => {
        const error = validateForm()
        if (error) return showMessage('error', error)
        setLoading(prev => ({ ...prev, submit: true }))
        try {
            const dataToSend = new FormData()
            dataToSend.append('plate_number', form.plateNumber.toUpperCase())
            dataToSend.append('location', form.location)
            dataToSend.append('fine_amount', form.fineAmount)
            dataToSend.append('image', image)
            const { data } = await api.post('/api/field-admin/capture', dataToSend)
            if (data.success) {
                showMessage('success', `Vehicle captured! Violation ID: ${data.violationId}`)
                resetForm()
                fetchViolations()
                setPage(1)
            } else {
                showMessage('error', data.message)
            }
        } catch (err) {
            showMessage('error', err.message)
        } finally {
            setLoading(prev => ({ ...prev, submit: false }))
        }
    }

    const handleLogout = async () => {
        try { await api.post('api/auth/logout') } finally { navigate('/login') }
    }

    // pagination logic
    const totalPages = Math.ceil(violations.length / PAGE_SIZE)
    const paginated = violations.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)

    return (
        <div>
            <div className="nav">
                <div className="logo">No Parking Pickup</div>
                <div className="nav-right">
                    <span className="nav-admin-name">{userData?.name}</span>
                    <button className="btn-logout" onClick={handleLogout}>Logout</button>
                </div>
            </div>

            <div className="field-wrap">
                <div style={{ width: '100%', maxWidth: '1100px' }}>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>

                        <div className="field-card">
                            <h2>Capture Violation</h2>

                            {message.text && (
                                <div className={message.type === 'success' ? 'alert-success' : 'alert-error'}>
                                    {message.text}
                                </div>
                            )}

                            <input
                                name="plateNumber"
                                placeholder="Plate Number"
                                value={form.plateNumber}
                                onChange={handleChange}
                                onBlur={lookupVehicle}
                            />
                            {loading.lookup && <small style={{ color: 'var(--text-muted)' }}>Looking up vehicle...</small>}

                            <input name="location" placeholder="Location" value={form.location} onChange={handleChange} />
                            <input type="number" name="fineAmount" value={form.fineAmount} onChange={handleChange} />
                            <input type="file" accept="image/*" capture="environment" onChange={handleImageChange} />

                            {ocrLoading && <small style={{ color: 'var(--text-muted)' }}>Reading plate...</small>}

                            {preview && (
                                <img src={preview} alt="preview" style={{ width: '100%', borderRadius: '10px' }} />
                            )}

                            <button onClick={handleSubmit} disabled={loading.submit}>
                                {loading.submit ? 'Capturing...' : 'Capture Vehicle'}
                            </button>
                        </div>

                        <div className="field-card">
                            <h2>Owner Details</h2>
                            {!ownerInfo ? (
                                <p style={{ color: 'var(--text-muted)' }}>Enter a plate number to look up owner</p>
                            ) : (
                                <div className="vp-rows">
                                    <div className="vp-row">
                                        <span className="vp-label">Name</span>
                                        <span className="vp-value">{ownerInfo.owner_name}</span>
                                    </div>
                                    <div className="vp-row">
                                        <span className="vp-label">Email</span>
                                        <span className="vp-value">{ownerInfo.owner_email}</span>
                                    </div>
                                    <div className="vp-row">
                                        <span className="vp-label">Phone</span>
                                        <span className="vp-value">{ownerInfo.owner_phone}</span>
                                    </div>
                                    <div className="vp-row">
                                        <span className="vp-label">Vehicle</span>
                                        <span className="vp-value">{ownerInfo.make} {ownerInfo.model}</span>
                                    </div>
                                    <div className="vp-row">
                                        <span className="vp-label">Color</span>
                                        <span className="vp-value">{ownerInfo.color}</span>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="admin-card" style={{ marginTop: '20px' }}>
                        <div className="acc">
                            <h2>My Captured Vehicles ({violations.length})</h2>
                        </div>

                        {loading.violations ? (
                            <div className="loading-text">Loading...</div>
                        ) : violations.length === 0 ? (
                            <div className="empty-state">
                                <span style={{ fontSize: '2rem' }}>🚗</span>
                                <strong>No violations captured yet</strong>
                            </div>
                        ) : (
                            <>
                                <div className="admin-table-wrap">
                                    <table className="admin-table">
                                        <thead>
                                            <tr>
                                                <th>Plate</th>
                                                <th>Owner</th>
                                                <th>Location</th>
                                                <th>Fine</th>
                                                <th>Status</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {paginated.map(v => (
                                                <tr key={v.id}>
                                                    <td style={{ fontWeight: 700, fontFamily: 'monospace', letterSpacing: '1px', color: 'var(--text-primary)' }}>
                                                        {v.plate_number}
                                                    </td>
                                                    <td>{v.owner_name}</td>
                                                    <td style={{ fontSize: '0.83rem' }}>{v.location}</td>
                                                    <td style={{ fontWeight: 700, color: '#92400e' }}>₹{v.fine_amount}</td>
                                                    <td>
                                                        <span className={`status-badge ${getViolationStatusClass(v.status)}`}>
                                                            {VIOLATION_STATUS_LABEL[v.status]}
                                                        </span>
                                                    </td>
                                                    <td style={{ fontSize: '0.82rem', color: 'var(--text-secondary)' }}>
                                                        {new Date(v.captured_at).toLocaleString('en-IN')}
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>

                                <div className="pagination">
                                    <button className="page-btn" onClick={() => setPage(p => p - 1)} disabled={page === 1}>← Prev</button>
                                    {Array.from({ length: totalPages }, (_, i) => (
                                        <button
                                            key={i + 1}
                                            className={`page-btn ${page === i + 1 ? 'active' : ''}`}
                                            onClick={() => setPage(i + 1)}
                                        >
                                            {i + 1}
                                        </button>
                                    ))}
                                    <button className="page-btn" onClick={() => setPage(p => p + 1)} disabled={page === totalPages}>Next →</button>
                                </div>
                            </>
                        )}
                    </div>

                </div>
            </div>
        </div>
    )
}

export default FieldAdmin